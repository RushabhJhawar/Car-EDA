# Car-data-analysis
Doing an in depth data cleaning and EDA project on this cars data.<br>
The data can be found at - https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/DA0101EN/automobileEDA.csv
